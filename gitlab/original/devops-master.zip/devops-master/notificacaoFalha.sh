#!/bin/bash

curl -X POST -H 'Content-type: application/json' --data '{"text":"ops! algo deu errado"}' https://hooks.slack.com/services/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